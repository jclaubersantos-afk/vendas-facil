package com.clauber.vendasfacil;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.provider.ContactsContract;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int LOCATION_PERMISSION_REQUEST = 41;
    private static final int CONTACT_PICKER_REQUEST = 42;
    private static final int CONTACTS_PERMISSION_REQUEST = 43;
    private static final String APP_URL = "https://jclaubersantos-afk.github.io/vendas-facil/";
    private static final String APP_HOST = "jclaubersantos-afk.github.io";

    private WebView webView;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(true);
        webView.addJavascriptInterface(new AndroidContactsBridge(), "AndroidContacts");

        CookieManager.getInstance().setAcceptCookie(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return routeUrl(request.getUrl().toString());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return routeUrl(url);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                requestLocationPermission(origin, callback);
            }

            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                WebView popup = new WebView(MainActivity.this);
                popup.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                        openExternal(request.getUrl().toString());
                        return true;
                    }

                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, String url) {
                        openExternal(url);
                        return true;
                    }

                    @Override
                    public void onPageStarted(WebView view, String url, Bitmap favicon) {
                        openExternal(url);
                        view.stopLoading();
                    }
                });
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(popup);
                resultMsg.sendToTarget();
                return true;
            }
        });

        webView.loadUrl(APP_URL);
    }

    private final class AndroidContactsBridge {
        @JavascriptInterface
        public void pickContact() {
            runOnUiThread(() -> openContactPicker());
        }

        @JavascriptInterface
        public void listContacts() {
            runOnUiThread(() -> requestContactListPermission());
        }
    }

    private void requestContactListPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M
                || checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            loadPhoneContacts();
            return;
        }
        requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, CONTACTS_PERMISSION_REQUEST);
    }

    private void loadPhoneContacts() {
        new Thread(() -> {
            JSONArray contacts = new JSONArray();
            Cursor phoneCursor = null;
            Cursor contactCursor = null;
            try {
                Map<String, String> phoneByContact = new HashMap<>();
                String[] phoneProjection = new String[]{
                        ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                        ContactsContract.CommonDataKinds.Phone.NUMBER
                };
                phoneCursor = getContentResolver().query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        phoneProjection, null, null,
                        ContactsContract.CommonDataKinds.Phone.IS_SUPER_PRIMARY + " DESC, "
                                + ContactsContract.CommonDataKinds.Phone.IS_PRIMARY + " DESC");
                if (phoneCursor != null) {
                    int idIndex = phoneCursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.CONTACT_ID);
                    int phoneIndex = phoneCursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER);
                    while (phoneCursor.moveToNext()) {
                        String id = phoneCursor.getString(idIndex);
                        if (id != null && !phoneByContact.containsKey(id)) {
                            phoneByContact.put(id, phoneCursor.getString(phoneIndex));
                        }
                    }
                    phoneCursor.close();
                    phoneCursor = null;
                }

                String[] contactProjection = new String[]{
                        ContactsContract.Contacts._ID,
                        ContactsContract.Contacts.DISPLAY_NAME
                };
                contactCursor = getContentResolver().query(
                        ContactsContract.Contacts.CONTENT_URI,
                        contactProjection, null, null,
                        ContactsContract.Contacts.DISPLAY_NAME + " COLLATE LOCALIZED ASC");
                if (contactCursor == null) {
                    callWebContactCallback("onAndroidContactsError", null);
                    return;
                }
                int idIndex = contactCursor.getColumnIndexOrThrow(ContactsContract.Contacts._ID);
                int nameIndex = contactCursor.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME);
                while (contactCursor.moveToNext()) {
                    String id = contactCursor.getString(idIndex);
                    JSONObject contact = new JSONObject();
                    contact.put("id", id == null ? "" : id);
                    contact.put("name", contactCursor.getString(nameIndex));
                    contact.put("phone", phoneByContact.get(id) == null ? "" : phoneByContact.get(id));
                    contacts.put(contact);
                }
                callWebContactsCallback(contacts);
            } catch (Exception ignored) {
                callWebContactCallback("onAndroidContactsError", null);
            } finally {
                if (phoneCursor != null) phoneCursor.close();
                if (contactCursor != null) contactCursor.close();
            }
        }).start();
    }

    private void callWebContactsCallback(JSONArray contacts) {
        callWebJsonCallback("onAndroidContactsLoaded", contacts.toString());
    }

    private void openContactPicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        try {
            startActivityForResult(intent, CONTACT_PICKER_REQUEST);
        } catch (Exception ignored) {
            callWebContactCallback("onAndroidContactError", null);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != CONTACT_PICKER_REQUEST) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            callWebContactCallback("onAndroidContactCancelled", null);
            return;
        }

        Cursor cursor = null;
        try {
            Uri contactUri = data.getData();
            cursor = getContentResolver().query(contactUri,
                    new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                            ContactsContract.CommonDataKinds.Phone.NUMBER},
                    null, null, null);
            if (cursor == null || !cursor.moveToFirst()) {
                callWebContactCallback("onAndroidContactError", null);
                return;
            }
            int nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
            int phoneIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
            JSONObject contact = new JSONObject();
            contact.put("name", nameIndex >= 0 ? cursor.getString(nameIndex) : "");
            contact.put("phone", phoneIndex >= 0 ? cursor.getString(phoneIndex) : "");
            callWebContactCallback("onAndroidContactSelected", contact);
        } catch (Exception ignored) {
            callWebContactCallback("onAndroidContactError", null);
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    private void callWebContactCallback(String callback, JSONObject contact) {
        callWebJsonCallback(callback, contact == null ? null : contact.toString());
    }

    private void callWebJsonCallback(String callback, String jsonArgument) {
        if (webView == null) return;
        String argument = jsonArgument == null ? "" : jsonArgument;
        String script = "if(typeof window." + callback + "==='function')window." + callback + "(" + argument + ");";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(script, null);
        });
    }

    private boolean routeUrl(String value) {
        Uri uri = Uri.parse(value);
        if (APP_HOST.equalsIgnoreCase(uri.getHost())) {
            return false;
        }
        if ("https".equalsIgnoreCase(uri.getScheme()) || "http".equalsIgnoreCase(uri.getScheme())) {
            openExternal(value);
        }
        return true;
    }

    private void openExternal(String value) {
        Uri uri = Uri.parse(value);
        String scheme = uri.getScheme();
        if (!"https".equalsIgnoreCase(scheme) && !"http".equalsIgnoreCase(scheme)) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception ignored) {
            Toast.makeText(this, "Não foi possível abrir este link.", Toast.LENGTH_SHORT).show();
        }
    }

    private void requestLocationPermission(String origin, GeolocationPermissions.Callback callback) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M
                || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            callback.invoke(origin, true, false);
            return;
        }
        pendingGeoOrigin = origin;
        pendingGeoCallback = callback;
        requestPermissions(new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
        }, LOCATION_PERMISSION_REQUEST);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CONTACTS_PERMISSION_REQUEST) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted) loadPhoneContacts();
            else callWebContactCallback("onAndroidContactsError", null);
            return;
        }
        if (requestCode != LOCATION_PERMISSION_REQUEST || pendingGeoCallback == null) return;
        boolean granted = false;
        for (int result : grantResults) {
            if (result == PackageManager.PERMISSION_GRANTED) {
                granted = true;
                break;
            }
        }
        pendingGeoCallback.invoke(pendingGeoOrigin, granted, false);
        pendingGeoCallback = null;
        pendingGeoOrigin = null;
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
