package com.clauber.vendasfacil.syncvalidation;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.util.Base64;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int LOCATION_PERMISSION_REQUEST = 41;
    private static final int CONTACT_PICKER_REQUEST = 42;
    private static final int CONTACTS_PERMISSION_REQUEST = 43;
    private static final int DOWNLOAD_PERMISSION_REQUEST = 44;
    private static final int NOTIFICATIONS_PERMISSION_REQUEST = 45;
    private static final String NOTIFICATION_CHANNEL_ID = "vendas_facil_events";
    private static final int FILE_CHOOSER_REQUEST = 45;
    private static final String APP_URL = "https://appassets.androidplatform.net/assets/index.html";
    private static final String APP_HOST = "appassets.androidplatform.net";

    private WebView webView;
    private WebViewAssetLoader assetLoader;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;
    private volatile byte[] pendingDownloadBytes;
    private volatile String pendingDownloadFilename;
    private ValueCallback<Uri[]> pendingFileChooserResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        createNotificationChannel();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setDatabaseEnabled(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(true);
        webView.addJavascriptInterface(new AndroidContactsBridge(), "AndroidContacts");
        webView.addJavascriptInterface(new AndroidShareBridge(), "AndroidShare");
        webView.addJavascriptInterface(new AndroidDownloadsBridge(), "AndroidDownloads");
        webView.addJavascriptInterface(new AndroidNotificationsBridge(), "AndroidNotifications");

        CookieManager.getInstance().setAcceptCookie(true);
        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return routeUrl(request.getUrl().toString());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return routeUrl(url);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (pendingFileChooserResult != null) pendingFileChooserResult.onReceiveValue(null);
                pendingFileChooserResult = callback;
                try {
                    Intent intent = params.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    Intent chooser = Intent.createChooser(intent, "Escolher arquivo de backup");
                    startActivityForResult(chooser, FILE_CHOOSER_REQUEST);
                } catch (Exception error) {
                    pendingFileChooserResult = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "Não foi possível abrir os arquivos.", Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                requestLocationPermission(origin, callback);
            }

            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                WebView popup = new WebView(MainActivity.this);
                popup.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                        openExternal(request.getUrl().toString());
                        return true;
                    }

                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, String url) {
                        openExternal(url);
                        return true;
                    }

                    @Override
                    public void onPageStarted(WebView view, String url, Bitmap favicon) {
                        openExternal(url);
                        view.stopLoading();
                    }
                });
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(popup);
                resultMsg.sendToTarget();
                return true;
            }
        });

        webView.loadUrl(APP_URL);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(NOTIFICATION_CHANNEL_ID,
                    "Vendalume", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Avisos sobre vendas registradas e estoque baixo");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private boolean hasNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) return false;
        return NotificationManagerCompat.from(this).areNotificationsEnabled();
    }

    private final class AndroidNotificationsBridge {
        @JavascriptInterface
        public boolean hasPermission() {
            return hasNotificationPermission();
        }

        @JavascriptInterface
        public void requestPermission() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33
                        && ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATIONS_PERMISSION_REQUEST);
                } else {
                    callWebNotificationPermission(hasNotificationPermission());
                }
            });
        }

        @JavascriptInterface
        public void openSettings() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                    intent.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                    startActivity(intent);
                } catch (Exception ignored) {
                    try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:" + getPackageName()))); } catch (Exception ignoredAgain) { }
                }
            });
        }

        @JavascriptInterface
        public void show(String title, String body, String tag) {
            runOnUiThread(() -> {
                if (!hasNotificationPermission()) return;
                String safeTitle = title == null || title.trim().isEmpty() ? "Vendalume" : title;
                String safeBody = body == null ? "" : body;
                int id = (tag == null ? safeTitle : tag).hashCode();
                NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivity.this, NOTIFICATION_CHANNEL_ID)
                        .setSmallIcon(R.drawable.ic_launcher)
                        .setContentTitle(safeTitle)
                        .setContentText(safeBody)
                        .setStyle(new NotificationCompat.BigTextStyle().bigText(safeBody))
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                        .setAutoCancel(true);
                try { NotificationManagerCompat.from(MainActivity.this).notify(id, builder.build()); }
                catch (SecurityException ignored) { }
            });
        }
    }

    private void callWebNotificationPermission(boolean granted) {
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(
                    "if(typeof window.onAndroidNotificationPermission==='function')window.onAndroidNotificationPermission(" + granted + ");", null);
        });
    }

    private final class AndroidContactsBridge {
        @JavascriptInterface
        public void pickContact() {
            runOnUiThread(() -> openContactPicker());
        }

        @JavascriptInterface
        public void listContacts() {
            runOnUiThread(() -> requestContactListPermission());
        }
    }

    private final class AndroidShareBridge {
        @JavascriptInterface
        public void shareFile(String base64, String filename, String mimeType, String title, String caption) {
            if (base64 == null || base64.length() > 15 * 1024 * 1024) {
                callWebShareError();
                return;
            }
            new Thread(() -> {
                try {
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                    if (bytes.length == 0 || bytes.length > 11 * 1024 * 1024) {
                        callWebShareError();
                        return;
                    }
                    File directory = new File(getCacheDir(), "shared_files");
                    if (!directory.exists() && !directory.mkdirs()) {
                        callWebShareError();
                        return;
                    }
                    String safeName = filename == null ? "vendalume-relatorio.pdf"
                            : filename.replaceAll("[^A-Za-z0-9._-]", "_");
                    if (safeName.isEmpty()) safeName = "vendalume-arquivo";
                    File outputFile = new File(directory, safeName);
                    try (FileOutputStream output = new FileOutputStream(outputFile)) {
                        output.write(bytes);
                        output.flush();
                    }
                    Uri contentUri = FileProvider.getUriForFile(
                            MainActivity.this, getPackageName() + ".fileprovider", outputFile);
                    String safeMime = mimeType == null ? "application/octet-stream" : mimeType.split(";")[0].trim();
                    if (!safeMime.matches("[A-Za-z0-9.+-]+/[A-Za-z0-9.+-]+")) {
                        safeMime = "application/octet-stream";
                    }
                    String chooserTitle = title == null || title.trim().isEmpty()
                            ? "Compartilhar arquivo" : title;
                    Intent sendIntent = new Intent(Intent.ACTION_SEND);
                    sendIntent.setType(safeMime);
                    sendIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
                    if (caption != null && !caption.trim().isEmpty()) {
                        sendIntent.putExtra(Intent.EXTRA_TEXT, caption);
                    }
                    sendIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    sendIntent.setClipData(ClipData.newUri(getContentResolver(), chooserTitle, contentUri));
                    Intent chooser = Intent.createChooser(sendIntent, chooserTitle);
                    chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    runOnUiThread(() -> {
                        try {
                            startActivity(chooser);
                        } catch (Exception ignored) {
                            callWebShareError();
                        }
                    });
                } catch (Exception ignored) {
                    callWebShareError();
                }
            }).start();
        }
    }

    private final class AndroidDownloadsBridge {
        @JavascriptInterface
        public void saveToDownloads(String base64, String filename, String mimeType) {
            if (base64 == null || base64.length() > 15 * 1024 * 1024) {
                callWebDownloadCallback("onAndroidDownloadError");
                return;
            }
            new Thread(() -> {
                byte[] bytes;
                try {
                    bytes = Base64.decode(base64, Base64.DEFAULT);
                    if (bytes.length == 0 || bytes.length > 11 * 1024 * 1024) {
                        callWebDownloadCallback("onAndroidDownloadError");
                        return;
                    }
                } catch (Exception error) {
                    callWebDownloadCallback("onAndroidDownloadError");
                    return;
                }
                String safeName = filename == null ? "fechamento-caixa.pdf"
                        : filename.replaceAll("[^A-Za-z0-9._-]", "_");
                if (safeName.isEmpty()) safeName = "fechamento-caixa.pdf";
                String safeMime = mimeType == null ? "application/pdf" : mimeType.split(";")[0].trim();
                if (!safeMime.matches("[A-Za-z0-9.+-]+/[A-Za-z0-9.+-]+")) safeMime = "application/pdf";
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q
                        && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    pendingDownloadBytes = bytes;
                    pendingDownloadFilename = safeName;
                    runOnUiThread(() -> requestPermissions(
                            new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, DOWNLOAD_PERMISSION_REQUEST));
                    return;
                }
                try {
                    saveDownload(bytes, safeName, safeMime);
                    callWebDownloadCallback("onAndroidDownloadSaved");
                } catch (Exception error) {
                    callWebDownloadCallback("onAndroidDownloadError");
                }
            }).start();
        }
    }

    private void saveDownload(byte[] bytes, String filename, String mimeType) throws Exception {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
            values.put(MediaStore.MediaColumns.MIME_TYPE, mimeType);
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IllegalStateException("Could not create Downloads entry");
            try (OutputStream output = getContentResolver().openOutputStream(uri, "w")) {
                if (output == null) throw new IllegalStateException("Could not open Downloads entry");
                output.write(bytes);
                output.flush();
            } catch (Exception error) {
                getContentResolver().delete(uri, null, null);
                throw error;
            }
            ContentValues published = new ContentValues();
            published.put(MediaStore.MediaColumns.IS_PENDING, 0);
            getContentResolver().update(uri, published, null, null);
            return;
        }
        File directory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if (!directory.exists() && !directory.mkdirs()) throw new IllegalStateException("Could not create Downloads directory");
        File outputFile = new File(directory, filename);
        try (FileOutputStream output = new FileOutputStream(outputFile)) {
            output.write(bytes);
            output.flush();
        }
        android.media.MediaScannerConnection.scanFile(this, new String[]{outputFile.getAbsolutePath()},
                new String[]{mimeType}, null);
    }

    private void callWebDownloadCallback(String callback) {
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(
                    "if(typeof window." + callback + "==='function')window." + callback + "();", null);
        });
    }

    private void callWebShareError() {
        runOnUiThread(() -> {
            if (webView != null) {
                webView.evaluateJavascript(
                        "if(typeof window.onAndroidShareError==='function')window.onAndroidShareError();", null);
            }
        });
    }

    private void requestContactListPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M
                || checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            loadPhoneContacts();
            return;
        }
        requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, CONTACTS_PERMISSION_REQUEST);
    }

    private void loadPhoneContacts() {
        new Thread(() -> {
            JSONArray contacts = new JSONArray();
            Cursor phoneCursor = null;
            Cursor contactCursor = null;
            try {
                Map<String, String> phoneByContact = new HashMap<>();
                String[] phoneProjection = new String[]{
                        ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                        ContactsContract.CommonDataKinds.Phone.NUMBER
                };
                phoneCursor = getContentResolver().query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        phoneProjection, null, null,
                        ContactsContract.CommonDataKinds.Phone.IS_SUPER_PRIMARY + " DESC, "
                                + ContactsContract.CommonDataKinds.Phone.IS_PRIMARY + " DESC");
                if (phoneCursor != null) {
                    int idIndex = phoneCursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.CONTACT_ID);
                    int phoneIndex = phoneCursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER);
                    while (phoneCursor.moveToNext()) {
                        String id = phoneCursor.getString(idIndex);
                        if (id != null && !phoneByContact.containsKey(id)) {
                            phoneByContact.put(id, phoneCursor.getString(phoneIndex));
                        }
                    }
                    phoneCursor.close();
                    phoneCursor = null;
                }

                String[] contactProjection = new String[]{
                        ContactsContract.Contacts._ID,
                        ContactsContract.Contacts.DISPLAY_NAME
                };
                contactCursor = getContentResolver().query(
                        ContactsContract.Contacts.CONTENT_URI,
                        contactProjection, null, null,
                        ContactsContract.Contacts.DISPLAY_NAME + " COLLATE LOCALIZED ASC");
                if (contactCursor == null) {
                    callWebContactCallback("onAndroidContactsError", null);
                    return;
                }
                int idIndex = contactCursor.getColumnIndexOrThrow(ContactsContract.Contacts._ID);
                int nameIndex = contactCursor.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME);
                while (contactCursor.moveToNext()) {
                    String id = contactCursor.getString(idIndex);
                    JSONObject contact = new JSONObject();
                    contact.put("id", id == null ? "" : id);
                    contact.put("name", contactCursor.getString(nameIndex));
                    contact.put("phone", phoneByContact.get(id) == null ? "" : phoneByContact.get(id));
                    contacts.put(contact);
                }
                callWebContactsCallback(contacts);
            } catch (Exception ignored) {
                callWebContactCallback("onAndroidContactsError", null);
            } finally {
                if (phoneCursor != null) phoneCursor.close();
                if (contactCursor != null) contactCursor.close();
            }
        }).start();
    }

    private void callWebContactsCallback(JSONArray contacts) {
        callWebJsonCallback("onAndroidContactsLoaded", contacts.toString());
    }

    private void openContactPicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        try {
            startActivityForResult(intent, CONTACT_PICKER_REQUEST);
        } catch (Exception ignored) {
            callWebContactCallback("onAndroidContactError", null);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            ValueCallback<Uri[]> callback = pendingFileChooserResult;
            pendingFileChooserResult = null;
            if (callback == null) return;
            if (resultCode != RESULT_OK || data == null) {
                callback.onReceiveValue(null);
                return;
            }
            ClipData clip = data.getClipData();
            if (clip != null && clip.getItemCount() > 0) {
                Uri[] results = new Uri[clip.getItemCount()];
                for (int index = 0; index < clip.getItemCount(); index++) results[index] = clip.getItemAt(index).getUri();
                callback.onReceiveValue(results);
            } else {
                Uri uri = data.getData();
                callback.onReceiveValue(uri == null ? null : new Uri[]{uri});
            }
            return;
        }
        if (requestCode != CONTACT_PICKER_REQUEST) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            callWebContactCallback("onAndroidContactCancelled", null);
            return;
        }

        Cursor cursor = null;
        try {
            Uri contactUri = data.getData();
            cursor = getContentResolver().query(contactUri,
                    new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                            ContactsContract.CommonDataKinds.Phone.NUMBER},
                    null, null, null);
            if (cursor == null || !cursor.moveToFirst()) {
                callWebContactCallback("onAndroidContactError", null);
                return;
            }
            int nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
            int phoneIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
            JSONObject contact = new JSONObject();
            contact.put("name", nameIndex >= 0 ? cursor.getString(nameIndex) : "");
            contact.put("phone", phoneIndex >= 0 ? cursor.getString(phoneIndex) : "");
            callWebContactCallback("onAndroidContactSelected", contact);
        } catch (Exception ignored) {
            callWebContactCallback("onAndroidContactError", null);
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    private void callWebContactCallback(String callback, JSONObject contact) {
        callWebJsonCallback(callback, contact == null ? null : contact.toString());
    }

    private void callWebJsonCallback(String callback, String jsonArgument) {
        if (webView == null) return;
        String argument = jsonArgument == null ? "" : jsonArgument;
        String script = "if(typeof window." + callback + "==='function')window." + callback + "(" + argument + ");";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(script, null);
        });
    }

    private boolean routeUrl(String value) {
        Uri uri = Uri.parse(value);
        if (APP_HOST.equalsIgnoreCase(uri.getHost())) {
            return false;
        }
        if ("https".equalsIgnoreCase(uri.getScheme()) || "http".equalsIgnoreCase(uri.getScheme())) {
            openExternal(value);
        }
        return true;
    }

    private void openExternal(String value) {
        Uri uri = Uri.parse(value);
        String scheme = uri.getScheme();
        if (!"https".equalsIgnoreCase(scheme) && !"http".equalsIgnoreCase(scheme)) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception ignored) {
            Toast.makeText(this, "Não foi possível abrir este link.", Toast.LENGTH_SHORT).show();
        }
    }

    private void requestLocationPermission(String origin, GeolocationPermissions.Callback callback) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M
                || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            callback.invoke(origin, true, false);
            return;
        }
        pendingGeoOrigin = origin;
        pendingGeoCallback = callback;
        requestPermissions(new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
        }, LOCATION_PERMISSION_REQUEST);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATIONS_PERMISSION_REQUEST) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            callWebNotificationPermission(granted && hasNotificationPermission());
            return;
        }
        if (requestCode == CONTACTS_PERMISSION_REQUEST) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted) loadPhoneContacts();
            else callWebContactCallback("onAndroidContactsError", null);
            return;
        }
        if (requestCode == DOWNLOAD_PERMISSION_REQUEST) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            final byte[] bytes = pendingDownloadBytes;
            final String filename = pendingDownloadFilename;
            pendingDownloadBytes = null;
            pendingDownloadFilename = null;
            if (!granted || bytes == null || filename == null) {
                callWebDownloadCallback("onAndroidDownloadError");
                return;
            }
            new Thread(() -> {
                try {
                    saveDownload(bytes, filename, "application/pdf");
                    callWebDownloadCallback("onAndroidDownloadSaved");
                } catch (Exception error) {
                    callWebDownloadCallback("onAndroidDownloadError");
                }
            }).start();
            return;
        }
        if (requestCode != LOCATION_PERMISSION_REQUEST || pendingGeoCallback == null) return;
        boolean granted = false;
        for (int result : grantResults) {
            if (result == PackageManager.PERMISSION_GRANTED) {
                granted = true;
                break;
            }
        }
        pendingGeoCallback.invoke(pendingGeoOrigin, granted, false);
        pendingGeoCallback = null;
        pendingGeoOrigin = null;
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.postDelayed(() -> {
            if (webView != null) webView.evaluateJavascript(
                    "if(typeof window.onVendalumeAppResume==='function')window.onVendalumeAppResume();else if(typeof window.refreshNotificationStatus==='function')window.refreshNotificationStatus();", null);
        }, 350);
    }

    @Override
    protected void onDestroy() {
        if (pendingFileChooserResult != null) {
            pendingFileChooserResult.onReceiveValue(null);
            pendingFileChooserResult = null;
        }
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
